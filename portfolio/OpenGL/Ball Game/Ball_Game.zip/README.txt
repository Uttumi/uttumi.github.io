Game commands
---------------------
Mouse left click: Launch the ball or reset the game.

a/z: Increase/decrease the launch speed of the ball. 

s/x: Increase/decrease tesselation of the walls and the floor. This affects the roughness of the spot light (and the game's performance).

p: Pause the game.

l: Main light on/off. Leaves only the spot light that is aimed at the ball.